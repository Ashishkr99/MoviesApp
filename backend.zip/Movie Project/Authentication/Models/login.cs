﻿namespace Authentication.Models
{
    public class login
    {
        public String Email { get; set; }
        public String Password { get; set; }
    }
}
